<?php

namespace App\Enums;

enum KaryawanStatusEnum: string
{
    case Harian = 'Harian';
    case Bulanan = 'Bulanan';
    case Borongan = 'Borongan';
}
